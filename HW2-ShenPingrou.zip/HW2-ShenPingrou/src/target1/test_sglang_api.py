import requests
import json

SERVER_URL = "http://127.0.0.1:30000"
GEN_URL = f"{SERVER_URL}/generate"

payload = {
    "input_ids": [101,102,103],
    "temperature":0,
    "max_new_tokens":16,
    "stream":True
}

resp = requests.post(GEN_URL, json=payload, stream=True)
print("status code:", resp.status_code)

for line in resp.iter_lines():
    if not line:
        continue
    line_str = line.decode("utf-8").strip()
    print("raw line:",line_str)
