import time
import json
import os
import threading
import requests
import numpy as np

SERVER_URL = "http://127.0.0.1:30000"
FLUSH_URL = f"{SERVER_URL}/flush_cache"
GEN_URL = f"{SERVER_URL}/generate"

# 作业固定参数
TEMPERATURE = 0
MAX_NEW_TOKENS = 16
IGNORE_EOS = True
SAMPLING_SEED = 2026
MAX_CONCURRENCY = 8
PER_GROUP_REQ = 32

BASE_OUT = "../../results/target1"

# 读取token
with open("token_lib.json", "r", encoding="utf-8") as f:
    token_data = json.load(f)
shared_prefix_2048 = token_data["shared_2048"]

def flush_cache():
    resp = requests.post(FLUSH_URL, timeout=30)
    assert resp.status_code == 200, "flush_cache failed"
    print("[+] Cache flushed ok")

def send_generate(payload, timeout=120):
    st_total = time.time()
    first_token_ts = None
    valid_data = []
    resp = requests.post(GEN_URL, json=payload, stream=True, timeout=timeout)
    for line in resp.iter_lines():
        if not line:
            continue
        line_str = line.decode("utf-8").strip()
        if line_str.startswith("data:"):
            data_content = line_str[5:].strip()
            if data_content == "[DONE]":
                continue
            if first_token_ts is None:
                first_token_ts = time.time()
            valid_data.append(data_content)
    end_total = time.time()
    total_latency = end_total - st_total
    ttft = first_token_ts - st_total if first_token_ts else None
    if len(valid_data) == 0:
        raise Exception("No valid data chunks received from SGLang")
    last_chunk = json.loads(valid_data[-1])

    # 直接读取顶层字段！！从日志看到cached_tokens就在顶层
    prompt_tokens = last_chunk.get("prompt_tokens", 0)
    cached_tokens = last_chunk.get("cached_tokens", 0)
    output_tokens = last_chunk.get("completion_tokens", 0)

    tpot = (total_latency - ttft) / (output_tokens - 1) if (output_tokens>1 and ttft is not None) else None
    return {
        "st_total": st_total,
        "end_total": end_total,
        "ttft": ttft,
        "tpot": tpot,
        "end2end": total_latency,
        "prompt_tokens": prompt_tokens,
        "cached_tokens": cached_tokens,
        "output_tokens": output_tokens,
        "raw": last_chunk
    }

def worker(idx, payload, out_list, fail_list):
    try:
        res = send_generate(payload)
        out_list.append({"req_idx": idx, **res})
    except Exception as e:
        print(f"req {idx} fail: {e}")
        fail_list.append(idx)

def run_group(group_name, payload_list, out_dir, warmup_payload=None):
    os.makedirs(out_dir, exist_ok=True)
    flush_cache()
    if warmup_payload is not None:
        print("[+] run warmup request, wait cache commit ...")
        send_generate(warmup_payload)
        time.sleep(3.0)
        print("[+] warmup done, submit measurement requests")

    out_list = []
    fail_list = []
    sem = threading.Semaphore(MAX_CONCURRENCY)
    threads = []
    def wrapped(i,p):
        with sem:
            worker(i,p, out_list, fail_list)
    for i,p in enumerate(payload_list):
        t = threading.Thread(target=wrapped, args=(i,p))
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
    with open(os.path.join(out_dir,"per_request.json"),"w",encoding="utf-8") as f:
        json.dump(out_list, f, ensure_ascii=False, indent=2)
    success_cnt = len(out_list)
    fail_cnt = len(fail_list)
    success_rate = success_cnt / PER_GROUP_REQ
    sum_prompt_tokens = sum(x["prompt_tokens"] for x in out_list)
    sum_cached_tokens = sum(x["cached_tokens"] for x in out_list)
    cache_hit_rate = sum_cached_tokens / sum_prompt_tokens if sum_prompt_tokens>0 else 0.0
    actual_prefill_tokens = sum_prompt_tokens - sum_cached_tokens

    ttft_arr = [x["ttft"] for x in out_list if x["ttft"] is not None]
    tpot_arr = [x["tpot"] for x in out_list if x["tpot"] is not None]
    e2e_arr = [x["end2end"] for x in out_list]

    def p50(arr):
        if len(arr) == 0:
            return 0.0
        return float(np.percentile(arr,50))
    def p95(arr):
        if len(arr) == 0:
            return 0.0
        return float(np.percentile(arr,95))

    metrics = {
        "group": group_name,
        "success_count": success_cnt,
        "fail_count": fail_cnt,
        "success_rate": success_rate,
        "sum_prompt_tokens": sum_prompt_tokens,
        "sum_cached_tokens": sum_cached_tokens,
        "cache_hit_rate": cache_hit_rate,
        "actual_prefill_tokens": actual_prefill_tokens,
        "ttft_p50": p50(ttft_arr),
        "ttft_p95": p95(ttft_arr),
        "tpot_p50": p50(tpot_arr),
        "tpot_p95": p95(tpot_arr),
        "end2end_p50": p50(e2e_arr),
        "end2end_p95": p95(e2e_arr),
    }
    with open(os.path.join(out_dir,"summary.json"),"w",encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
    print("\n======= Group Summary Result =======")
    print(json.dumps(metrics,indent=2))
    return metrics

def main():
    suffix_64_list = [ [100+i]*64 for i in range(PER_GROUP_REQ) ]
    shared_payloads = []
    for suf in suffix_64_list:
        input_ids = shared_prefix_2048 + suf
        pl = {
            "input_ids": input_ids,
            "temperature": TEMPERATURE,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": IGNORE_EOS,
            "sampling_seed": SAMPLING_SEED,
            "stream": True
        }
        shared_payloads.append(pl)
    warmup_pl = {
        "input_ids": shared_prefix_2048 + [1]*64,
        "temperature": TEMPERATURE,
        "max_new_tokens": MAX_NEW_TOKENS,
        "ignore_eos": IGNORE_EOS,
        "sampling_seed": SAMPLING_SEED,
        "stream": True
    }
    dispersed_payloads = []
    for i in range(PER_GROUP_REQ):
        seq = [ 2000 + i ] + [5]*2111
        pl = {
            "input_ids": seq,
            "temperature": TEMPERATURE,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": IGNORE_EOS,
            "sampling_seed": SAMPLING_SEED,
            "stream": True
        }
        dispersed_payloads.append(pl)

    print("===== Run shared-prefix group =====")
    run_group("shared_prefix", shared_payloads,
              out_dir=os.path.join(BASE_OUT,"shared_prefix/run-4"),
              warmup_payload=warmup_pl)

    print("\n===== Run dispersed-prefix group =====")
    run_group("dispersed_prefix", dispersed_payloads,
              out_dir=os.path.join(BASE_OUT,"dispersed_prefix/run-4"),
              warmup_payload=None)

if __name__ == "__main__":
    main()
