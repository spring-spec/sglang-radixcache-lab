from transformers import AutoTokenizer
import json

# 加载本地Qwen3‑0.6B模型tokenizer
tok = AutoTokenizer.from_pretrained("/root/autodl-tmp")

# 生成足够长文本，encode得到token ids
base_text = "repeat text " * 4000
all_ids = tok.encode(base_text)

# 截取2048长度共享前缀
shared_2048 = all_ids[:2048]

# 保存，给压测脚本读取
save_data = {
    "shared_2048": shared_2048
}
with open("token_lib.json", "w", encoding="utf-8") as f:
    json.dump(save_data, f)

print(f"生成完成，共享前缀长度:{len(shared_2048)}")
