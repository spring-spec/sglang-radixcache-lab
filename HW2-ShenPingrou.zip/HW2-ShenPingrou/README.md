# HW2 SGLang RadixCache 实验
## 实验环境
硬件：RTX4090D 24G
系统：Ubuntu22.04
软件版本：Python3.12，CUDA13.0，PyTorch2.12.1，SGLang，Ray

## 安装方法
```bash
# 创建Python虚拟环境
python -m venv env
source env/bin/activate
# 安装依赖
pip install sglang ray
```

## 启动与回放命令
```bash
# 启动SGLang服务
python -m sglang.launch_server --model 模型路径

# 执行压测脚本
python src/target1/benchmark.py
```

## 脚本用途
benchmark脚本用于构造并发请求，分为共享前缀、分散前缀两组实验，采集TTFT、token吞吐等推理指标，输出json结果保存至results目录。

## 结果目录与报告对应关系
results/target1/shared_prefix：实验组，请求拥有相同prompt前缀，RadixCache可以复用KV缓存
results/target1/dispersed_prefix：对照组，请求前缀互不相同，无法复用缓存

报告中表格、图表的数据均来自对应run-4下的summary.json与per_request.json。
```